﻿
Int32 xp;
string names;
string answer;
Int32 randomnumber;

xp = 0;
Console.WriteLine("Hello, and welcome to breadbtw a game about the best thing ever bread");
Console.WriteLine("But before we begin i need to know your name");
 names = (Console.ReadLine());
 Console.WriteLine("Welcome to bread btw, " + names + " its time to make some bread");
 Console.WriteLine("because you are new to making bread you can only make bread and roll");
 xp++; Console.WriteLine("to start you off i will give you 1 xp you now have " + xp + " xp");
 Console.WriteLine("to bake say bread to make bread");
 answer = (Console.ReadLine());
 if (answer == "bread")
 {
    Console.WriteLine("you made bread ");
    Random rnd = new Random();

for(int j = 0; j < 1; j++)
{
    randomnumber = rnd.Next(1, 4);
    Console.WriteLine("your bread type was rated " + randomnumber + "/4 by our judges"); 
    if (Convert.ToString(randomnumber) == "1") { xp++;}
    if (Convert.ToString(randomnumber) == "2") { xp++; xp++;}
    if (Convert.ToString(randomnumber) == "3") { xp++; xp++; xp++;}
    if (Convert.ToString(randomnumber) == "4") { xp++; xp++; xp++; xp++;}
    
}
 }
Console.WriteLine("you now have " + xp + " xp and have made your first bread");
if (xp <= Convert.ToInt32("3"))
{ Console.WriteLine("congratulations you have " + xp + " and have unlocked rolls and can get higher xp from them");
Console.WriteLine("to use rolls say rolls to make bread again press enter");} 
else {Console.WriteLine("unfortuantly you have " + xp + " xp which is not enough to unlock a new bread type");}

 Console.ReadKey();


